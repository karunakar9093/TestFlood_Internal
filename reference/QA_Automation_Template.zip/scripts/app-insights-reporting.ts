require("dotenv").config();
import * as appInsights from "applicationinsights";
import { readFileSync, readdirSync } from "fs-extra";
import Logger from "../support/logger";
(() => {
  const files = readdirSync("./reports");
  const uuidRegex =
    /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}.json$/;
  const filteredFiles = files.filter((file) => uuidRegex.test(file));
  const scenariosReport: Record<string, any>[] = [];
  filteredFiles.forEach((scenarioFile) => {
    const scenarioReport = readFileSync(`./reports/${scenarioFile}`, "utf-8");
    const scenarioReportJson = JSON.parse(scenarioReport);
    const scenarioSum: Record<string, number> = scenarioReportJson.aggregate.summaries;
    const scenarioCounters: Record<string, number> = scenarioReportJson.aggregate.counters;
    const scenariosTestData = readFileSync("./reports/test.json", "utf-8");
    const scenariosTestDataJson: Record<string, any> = JSON.parse(scenariosTestData);
    Object.keys(scenarioSum).forEach((scenarioPerfKey) => {
      if (scenarioPerfKey.startsWith("user.scenario.")) {
        const scenarioSummaryData: Record<string, any> = {};
        const scenarioTestData = scenariosTestDataJson.filter(
          (testData) => testData.scenarioName === scenarioPerfKey
        );
        const scenarioCommonData: Record<string, any> = {
          vus: scenarioTestData[0].vus,
          appEnvironment: scenarioTestData[0].appEnvironment,
          testScope: scenarioTestData[0].testScope,
          scenario: scenarioTestData[0].scenario,
          scenarioName: scenarioTestData[0].scenarioName,
          aut: scenarioTestData[0].aut,
        };
        scenarioTestData.forEach((testData: Record<string, any>) => {
          delete testData.vus;
          delete testData.appEnvironment;
          delete testData.testScope;
          delete testData.scenario;
          delete testData.scenarioName;
          delete testData.aut;
        });
        scenarioSummaryData["performance"] = scenarioSum[scenarioPerfKey];
        scenarioSummaryData["scenarioCounters"] = scenarioCounters;
        scenarioSummaryData["scenarioInfo"] = scenarioCommonData;
        scenarioSummaryData["vuTestInfo"] = scenarioTestData;
        scenariosReport.push(scenarioSummaryData);
      }
    });
  });

  let client;
  const finalReport: any[] = [];
  const isLocal: boolean = process.env.IS_LOCAL?.toLowerCase() === "true";
  const willBeLoggedInAppInsights: boolean =
    isLocal == true && process.env.APPLICATIONINSIGHTS_CONNECTION_STRING != null;
  if (willBeLoggedInAppInsights) {
    appInsights.setup(process.env.APPLICATIONINSIGHTS_CONNECTION_STRING).start();
    client = appInsights.defaultClient;
  }
  scenariosReport.forEach((scenarioSummary: any) => {
    const metric = {
      name: `${scenarioSummary.scenarioInfo.aut}.${scenarioSummary.scenarioInfo.scenario}`,
      namespace: "performance-testing",
      value: scenarioSummary.performance["p90"],
      max: scenarioSummary.performance["p75"],
      kind: "Aggregation",
      count: scenarioSummary.scenarioInfo.vus,
      properties: {
        performance: scenarioSummary.performance,
        scenarioCounters: scenarioSummary.scenarioCounters,
        scenarioInfo: scenarioSummary.scenarioInfo,
        vuTestInfo: scenarioSummary.vuTestInfo,
      },
    };
    if (willBeLoggedInAppInsights) {
      client.trackMetric(metric);
    } else {
      finalReport.push(metric);
    }
  });
  if (willBeLoggedInAppInsights) {
    client.flush();
  } else {
    Logger.info(JSON.stringify(finalReport));
  }
})();
