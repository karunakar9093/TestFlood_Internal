require("dotenv").config();
import { chromium } from "@playwright/test";
import * as fs from "fs-extra";
import { getEnvironmentUrl } from "../shared/assets/application-urls";
import AuthenticationApi from "../shared/api/controllers/auth.api";
import Logger from "../support/logger";
(async () => {
  const sessionFilePath = ".//shared/assets/sessions/session.json";

  await fs.remove(sessionFilePath);
  await fs.emptyDir(".//reports");
  await fs.emptyDir(".//logs");
  const browser = await chromium.launch({
    headless: true,
  });
  const baseUrl = getEnvironmentUrl("host");
  const context = await browser.newContext({
    baseURL: baseUrl,
  });
  const page = await context.newPage();
  let authApi = new AuthenticationApi(page.request);
  let authToken = await authApi.login();
  await fs.writeFile(sessionFilePath, JSON.stringify({ token: authToken }));
  await page.close();
  await browser.close();
  Logger.info(`Saved session storage from ${baseUrl} in '${sessionFilePath}'`);
})();
