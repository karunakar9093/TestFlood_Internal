# ESLint Rules in the project

This document provides an overview of the ESLint rules and guidelines set up for maintaining code quality and consistency within this TypeScript project.

## Table of Contents

1. [Introduction](#introduction)
   1. [Why use a linter?](#why-use-a-linter)
2. [Configuration](#configuration)
   1. [Plugins, configs and rules](#plugins-configs-and-rules)
   2. [How to customize rules](#how-to-customize-rules)
   3. [Naming rules](#naming-rules)
3. [Final notes](#final-notes)

## Introduction

ESLint is a powerful tool for enforcing coding standards and identifying potential issues in your codebase. In this project, we leverage ESLint with a customized set of rules tailored specifically for our needs. These rules are designed to enhance readability, maintainability, and overall code quality. Eslint and its rules are already configured in the template project, you don't need to run additional steps from the specified on the "Step by step guide" in the README.md file.

### Why use a linter?

- **Consistency**: ESLint ensures that all team members follow the same coding standards, leading to a more consistent codebase.
- **Early Detection**: ESLint helps catch potential issues and bugs early in the development process, reducing the likelihood of introducing errors.
- **Maintainability**: By enforcing best practices and a consistent coding style, ESLint makes the codebase more maintainable over time.

## Configuration

The ESLint configuration for this project is defined in the `.eslintrc.js` file in the root path, and the rules and settings can be customized in there according to your specific requirements.

### Plugins, configs and rules

In ESLint, plugins, configurations (configs), and rules play distinct roles in defining and enforcing coding standards.

- **Plugins:** They are specialized modules that extend ESLint's capabilities for specific technologies or patterns, such as Playwright or TypeScript.
- **Configurations (configs):** Define how ESLint should lint code by specifying which rules to apply and can be predefined, custom, or extend other configurations.
- **Rules:** They are the specific and individual guidelines that are verified.

These are used plugins and configuration used and their purpose:

- **eslint-config-airbnb-base** and **eslint-config-airbnb-typescript:** These configs provide the base rules and guidelines that are used in the Airbnb projects (widely recognize in the industry by their high-quality and good practices).
- **eslint-plugin-prettier** and **eslint-config-prettier:** Ensures code style consistency and avoids conflicts between ESLint and Prettier configurations.
- **eslint-plugin-import:** Contains rules for import statements in JS and TS code.
- **eslint-plugin-playwright:** Adds the capability to evaluate Playwright implementations and contains rules specifically designed for this library.
- **eslint-plugin-project-structure:** Enforces the use of an specific project structure and naming in files and folders. This can help maintain a standardized organization of files and directories within a codebase.
- **eslint-plugin-unused-imports:** Allows to identify and report unused imports.
- **eslint-plugin-yml:** Extends ESLint to lint YAML files, offering rules to ensure proper formatting and adherence to best practices when working with YAML configuration files.
- **@regru/eslint-plugin-prefer-early-return:** Introduces rules encouraging the use of early returns in functions, potentially improving performance by reducing nested logic.

### How to customize rules

The ESLint rules can be customized in the file `.eslintrc.cjs`, you can add, update or remove rules, configs and plugins on it. You can find the official documentation for that [here](https://eslint.org/docs/latest/use/configure/).

### Naming rules:

The project controls the naming rules in folders, files, and the actual code using the native ESLint rules and the project-structure plugin. These are the main implemented rules:

| Scope     | Valid naming style                   |
| --------- | ------------------------------------ |
| import    | camelCase, UPPER_CASE, or PascalCase |
| property  | camelCase                            |
| variable  | camelCase                            |
| booleans  | PascalCase with predefined prefixes  |
| const     | camelCase or UPPER_CASE              |
| enum      | UPPER_CASE                           |
| method    | camelCase                            |
| interface | PascalCase                           |
| folders   | kebab-case or snake_case             |

For more information, go to the Readme file or check the `@typescript-eslint/naming-convention` rules in `.eslintrc.cjs` file.

### Final notes:

- The project structure is defined in the `projectStructure.json`, if you need to create new directories that are not considered in this template, please update that JSON in your project to include those folders.
