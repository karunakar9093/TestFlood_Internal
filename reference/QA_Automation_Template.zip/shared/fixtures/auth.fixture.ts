import { test as base } from "@playwright/test";
import AuthenticationApi from "../../shared/api/controllers/auth.api";

export const authenticatedTest = base.extend<{ authToken: string }>({
  authToken: [
    async ({ page }, use) => {
      let authApi = new AuthenticationApi(page.request);
      let authToken = await authApi.login();
      await use(authToken);
    },
    { auto: true },
  ],
});

export { expect } from "@playwright/test"; //Exporting 'expect' from the base test so you have access in your spec.ts file.
