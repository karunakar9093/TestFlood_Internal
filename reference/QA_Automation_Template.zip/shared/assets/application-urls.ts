/**
 * Object containing URLs for different environments.
 */
const environmentUrls = {
  prod: {
    api: "https://api.demoblaze.com/login",
    host: "https://www.demoblaze.com/",
  },
};

const apiEnvUrl = getEnvironmentUrl("api");
const uiEnvUrl = getEnvironmentUrl("host");
/**
 * Object containing URL paths to make the APIs calls.
 */
export const urlPaths = {
  authentication: {
    api: {
      login: () => new URL(`/login`, apiEnvUrl),
    },
  },
  cart: {
    ui: {
      home: () => new URL(`/cart.html`, uiEnvUrl),
    },
    api: {
      addToCart: () => new URL(`/addtocart`, apiEnvUrl),
    },
  },
  article: {
    ui: {
      details: (articleId: String) => new URL(`/prod.html?idp_=${articleId}`, uiEnvUrl),
    },
  },
};

export type AppEnvironments = "dev" | "qa" | "demo" | "prod" | "DEV" | "QA" | "DEMO" | "PROD";

/**
 * Get the URL for a specific key in a given environment.
 *
 * @param {string} urlKey - The key identifying the URL.
 * @param {AppEnvironments} environment - The environment for which to retrieve the URL.
 * @returns {string} The URL for the specified key and environment.
 * @throws {Error} If the environment or URL key is invalid or not found.
 */
export function getEnvironmentUrl(urlKey: string, environment?: AppEnvironments): string {
  environment ??= process.env.APP_ENVIRONMENT as AppEnvironments;
  if (environment == null)
    throw new Error(
      `Invalid environment value: '${environment}'. Set your environment variable APP_ENVIRONMENT to a valid value ('DEV' | 'QA' | 'DEMO' | 'PROD')`
    );
  const url = environmentUrls[environment.toLowerCase()]?.[urlKey];
  if (url == null)
    throw new Error(
      `No existing value for url key: ${urlKey} in '${environment}' environment. Check lereta-urls.ts file.`
    );
  return url;
}
