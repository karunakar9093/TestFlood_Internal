/**
 * Collection of predefined test products classified by env.
 */
export const products = {
  prod: [
    {
      productId: "1",
      productName: "Samsung galaxy s6",
    },
    {
      productId: "6",
      productName: "Sony xperia z5",
    },
    {
      productId: "8",
      productName: "Sony vaio i5",
    },
  ],
};

/**
 * Function to retrieve a random product from the predefined products.
 * @returns {Object} A randomly selected product object.
 */
export const randomProduct = () => {
  if (process.env.APP_ENVIRONMENT == null)
    throw new Error("Invalid Application Environment, please set up your env var APP_ENVIRONMENT");
  const allProducts = products[process.env.APP_ENVIRONMENT.toLowerCase()];
  const randomIndex = Math.floor(Math.random() * allProducts.length);
  return allProducts[randomIndex];
};
