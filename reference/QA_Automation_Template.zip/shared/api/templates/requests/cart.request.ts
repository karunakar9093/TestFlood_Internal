import { headers } from "../headers/standard.headers";
import { v4 as uuidv4 } from "uuid";

/**
 * Collection of HTTP requests related to the cart operations.
 */
export const requests = {
  /**
   * Request to add a product to the cart.
   * @param {string} token - The authentication token, it can be obtained from the login request.
   * @param {string} productId - The ID of the product to be added to the cart.
   * @param {string} requestId - The unique request ID (default: generated using uuidv4()).
   * @param {boolean} willFailOnStatusCode - Whether to fail on non-2xx status codes (default: true).
   * @returns {Object} The request configuration.
   */
  addToCart: (
    token: string,
    productId: string,
    requestId: string = uuidv4(),
    willFailOnStatusCode = true
  ) => {
    return {
      data: {
        id: requestId,
        cookie: token,
        prod_id: productId,
        flag: true,
      },
      headers: headers.common,
      timeout: 10000,
      failOnStatusCode: willFailOnStatusCode,
    };
  },
};
