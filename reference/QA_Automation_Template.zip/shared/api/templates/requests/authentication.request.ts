import { headers } from "../headers/standard.headers";

/**
 * Collection of HTTP requests related to the authentication.
 */
export const requests = {
  /**
   * Request to perform user login.
   * @param {string} username - The username for login (default: value from process.env.APP_LOGIN_USER).
   * @param {string} password - The password for login (default: value from process.env.APP_LOGIN_PASSWORD).
   * @param {boolean} willFailOnStatusCode - Whether to fail on non-2xx status codes (default: true).
   * @returns {Object} The request configuration.
   */
  login: (
    username = process.env.APP_LOGIN_USER,
    password = process.env.APP_LOGIN_PASSWORD,
    willFailOnStatusCode = true
  ) => {
    return {
      data: {
        username: username,
        password: password,
      },
      headers: headers.common,
      timeout: 10000,
      failOnStatusCode: willFailOnStatusCode,
    };
  },
};
