/**
 * Common HTTP headers for API requests.
 */
export const headers = {
  common: {
    "Content-Type": "application/json",
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.36 OS/10.0.22621",
    Accept: "*/*",
    "Accept-Encoding": "gzip, deflate, br",
    host: "api.demoblaze.com",
  },
};
