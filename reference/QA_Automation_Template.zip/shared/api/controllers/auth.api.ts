import { urlPaths } from "../../../shared/assets/application-urls";
import BaseController from "./base-controller";
import { requests as authenticationRequests } from "../../../shared/api/templates/requests/authentication.request";
import { expect } from "@playwright/test";

export default class AuthenticationApi extends BaseController {
  async login(): Promise<string> {
    const loginUrl = urlPaths.authentication.api.login().toString();
    const loginResponse = await this.apiContext.post(loginUrl, authenticationRequests.login());
    expect(await loginResponse.text()).not.toContain("error");
    const authToken = (await loginResponse.text()).split(" ")[1].replace(/[\n\r"]/g, "");
    expect(authToken).not.toBeNull();
    return authToken;
  }
}
