import { urlPaths } from "../../../shared/assets/application-urls";
import BaseController from "./base-controller";
import { requests as cartRequests } from "../../../shared/api/templates/requests/cart.request";
import { APIRequestContext } from "@playwright/test";

export default class CartApi extends BaseController {
  /**
   *
   */
  constructor(
    apiContext: APIRequestContext,
    private authToken: string
  ) {
    super(apiContext);
  }

  async addToCart(articleId: string, requestId?: string) {
    const addToCartUrl = urlPaths.cart.api.addToCart().toString();
    return this.apiContext.post(
      addToCartUrl,
      cartRequests.addToCart(this.authToken, articleId, requestId, this.willFailOnStatusCode)
    );
  }
}
