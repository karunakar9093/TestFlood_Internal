import { APIRequestContext } from "@playwright/test";
import SchemaValidation from "../../../support/api/schema-validation";

export default abstract class BaseController {
  schemaValidation: SchemaValidation;

  constructor(
    protected apiContext: APIRequestContext,
    public willFailOnStatusCode = true,
    public timeout = 10000
  ) {
    this.schemaValidation = new SchemaValidation();
  }
}
