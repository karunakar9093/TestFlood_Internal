export enum EventStatus {
  FAILED,
  COMPLETED,
  UNCOMPLETED,
}
export enum TestScope {
  UI,
  API,
  UNSPECIFIED,
}
