import { Locator, Page } from "@playwright/test";

export default abstract class BasePage {
  protected Selectors: Record<any, Locator>;

  timeout = 10000;

  constructor(protected page: Page) {}

  abstract goto(...args): Promise<void>;
  abstract waitForPageToLoad(): Promise<void>;
  abstract refresh(): Promise<void>;
}
