import { Locator, Page } from "@playwright/test";
const initSelectors = (page: Page): Record<string, Locator> => {
  return {
    loginLink: page.locator("#login2"),
    cartLink: page.locator("#cartur"),
    loginModal: page.locator("#logInModal div.modal-content"),
    userInput: page.locator("#loginusername"),
    passwordInput: page.locator("//input[@id='loginpassword']"),
    loginButton: page.getByRole("button").and(page.getByText("Log in")),
    loginButton2: page.locator("div#logInModal button.btn-primary"),
    get reuseExample() {
      return this.loginLink.locator("anotherChildLocator");
    },
  };
};
export default initSelectors;
