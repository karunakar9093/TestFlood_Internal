import { Page } from "@playwright/test";
import BasePage from "../base-page";
import initSelectors from "./home.selectors.po";
import { getEnvironmentUrl } from "../../../shared/assets/application-urls";

export class HomePage extends BasePage {
  constructor(page: Page) {
    super(page);
    this.Selectors = initSelectors(page);
  }

  async goto(): Promise<void> {
    await this.page.goto(getEnvironmentUrl("host"));
  }

  async waitForPageToLoad(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  async refresh(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  /**
   * Opens the article with the specified name by clicking on its link.
   *
   * @param {string} articleName - The name of the article to be opened.
   * @returns {Promise<Page>} A promise that resolves with the Page object after opening the article.
   */
  async openArticleByName(articleName: string) {
    await this.Selectors.articleLinks.filter({ hasText: articleName }).click();
    return this.page;
  }
}
