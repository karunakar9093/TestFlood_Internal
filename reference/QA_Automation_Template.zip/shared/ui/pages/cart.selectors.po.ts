import { Locator, Page } from "@playwright/test";
const initSelectors = (page: Page): Record<string, Locator> => {
  return {
    productsList: page.locator("#tbodyid tr.success"),
    get reuseExample() {
      return this.productsList.locator("anotherChildLocator");
    },
  };
};
export default initSelectors;
