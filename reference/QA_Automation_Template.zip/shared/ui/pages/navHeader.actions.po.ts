import { expect, Page } from "@playwright/test";
import BasePage from "../base-page";
import initSelectors from "./navHeader.selectors.po";

export class NavHeaderPage extends BasePage {
  constructor(page: Page) {
    super(page);
    this.Selectors = initSelectors(page);
  }

  async goto(): Promise<void> {
    throw new Error("No browser path available.");
  }

  async waitForPageToLoad(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  async refresh(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  /**
   * Performs the login action with the specified or default user credentials.
   *
   * @param {string} email - The email address used for login (default: value from process.env.APP_LOGIN_USER).
   * @param {string} password - The password used for login (default: value from process.env.APP_LOGIN_PASSWORD).
   * @returns {Promise<void>} A promise that resolves when the login action is complete.
   */
  async doLogin(email?: string, password?: string) {
    email ??= process.env.APP_LOGIN_USER;
    password ??= process.env.APP_LOGIN_PASSWORD;
    if (email == null)
      throw new Error("Login user required. Should be set by parameters or env var APP_LOGIN_USER");
    if (password == null)
      throw new Error(
        "Login user required. Should be set by parameters or env var APP_LOGIN_PASSWORD"
      );
    await this.Selectors.loginLink.click();
    await expect(this.Selectors.loginModal).toBeVisible();
    await this.Selectors.userInput.fill(email);
    await this.Selectors.passwordInput.fill(password);
    await this.Selectors.loginButton2.click({ timeout: 10000 });
  }

  /**
   * Navigates to the shopping cart by clicking the cart link and verifies the URL.
   *
   * @returns {Promise<Page>} A promise that resolves with the Page object after navigating to the cart.
   */
  async goToCart() {
    await this.Selectors.cartLink.click();
    await expect(this.page).toHaveURL(/cart/);
    return this.page;
  }
}
