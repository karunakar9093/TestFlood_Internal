import { type Page } from "@playwright/test";
import { expect } from "chai";
import BasePage from "../base-page";
import initSelectors from "./cart.selectors.po";
import { urlPaths } from "../../../shared/assets/application-urls";

export class CartPage extends BasePage {
  constructor(page: Page) {
    super(page);
    this.Selectors = initSelectors(page);
  }

  async goto(): Promise<void> {
    await this.page.goto(urlPaths.cart.ui.home().toString());
  }

  async waitForPageToLoad(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  async refresh(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  /**
   * Verifies if an article with the specified name is present in the list of products added to the cart.
   *
   * @param {string} articleName - The name of the article to be verified.
   * @returns {Promise<void>} A promise that resolves when the verification is complete.
   * @throws {Error} If the article with the specified name is not found in the products list.
   */
  async verifyArticleIsPresent(articleName: string): Promise<void> {
    expect(await this.Selectors.productsList.filter({ hasText: articleName }).first().isVisible())
      .to.be.true;
  }
}
