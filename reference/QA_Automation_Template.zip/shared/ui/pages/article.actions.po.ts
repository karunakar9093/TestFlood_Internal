import { Page, expect } from "@playwright/test";
import BasePage from "../base-page";
import initSelectors from "./article.selectors.po";
import { urlPaths } from "../../../shared/assets/application-urls";

export class ArticlePage extends BasePage {
  constructor(page: Page) {
    super(page);
    this.Selectors = initSelectors(page);
  }

  async goto(articleId: string): Promise<void> {
    await this.page.goto(urlPaths.article.ui.details(articleId).toString());
  }

  async waitForPageToLoad(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  async refresh(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  /**
   * Verifies if the article name in the title matches the expected name.
   *
   * @param {string} expectedName - The expected name of the article.
   * @returns {Promise<void>} A promise that resolves when the verification is complete.
   * @throws {Error} If the article name does not match the expected name.
   */
  async verifyArticleName(expectedName: string) {
    await expect(this.Selectors.articleNameTitle).toHaveText(expectedName);
  }

  /**
   * Clicks the "Add to Cart" button to add the article to the shopping cart.
   *
   * @returns {Promise<void>} A promise that resolves when the article is successfully added to the cart.
   */
  async addArticleToCart() {
    await this.Selectors.addToCartButton.click();
  }
}
