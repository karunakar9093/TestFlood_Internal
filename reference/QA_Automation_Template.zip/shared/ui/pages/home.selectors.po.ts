import { Locator, Page } from "@playwright/test";
const initSelectors = (page: Page): Record<string, Locator> => {
  return {
    articleLinks: page.locator("h4.card-title a.hrefch"),
    get reuseExample() {
      return this.productsList.locator("anotherChildLocator");
    },
  };
};
export default initSelectors;
