import { Locator, Page } from "@playwright/test";
const initSelectors = (page: Page): Record<string, Locator> => {
  return {
    addToCartButton: page.getByText("Add to cart"),
    articleNameTitle: page.locator("h2.name"),
    get reuseExample() {
      return this.addToCartButton.locator("anotherChildLocator");
    },
  };
};
export default initSelectors;
