# Table of contents

1. [Introduction](#introduction)
2. [Project structure](#project-structure)
3. [Project Set up](#installation-guide)
   1. [Step by step guide](#step-by-step-guide)
   2. [Trouble shooting](#trouble-shooting)
   3. [Suggested plugins in VS Code](#plugins)
4. [Creating new tests](#new-test)
   1. [UI test](#new-ui-test)
   2. [API test](#new-api-test)
   3. [Performance test](#new-performance-test)
5. [Running tests](#running-tests)
6. [Additional features](#additional-features)
   1. [Linter - ESLint](#linter)
   2. [Code formatter - Prettier](#code-formatter)
   3. [Git hooks](#git-hooks)

> :warning: This is only a template project and it should be used as a starting point for others. To implement your automation, please fork this project or clone it and change the remote reference to your own repository.

## 1. Introduction <a id="introduction"></a>

Welcome to the automation template project of Bullet, a robust solution designed for ensuring the quality and reliability of software. This project is built using TypeScript, providing a strong foundation for creating maintainable and scalable code. The testing suite encompasses functional tests at both the UI and API levels, utilizing the versatility of the Playwright framework. In addition to functional testing, performance testing is a key focus, covering both UI and API scenarios with the powerful Artillery tool, seamlessly integrated with the Playwright engine. To enhance visibility and traceability, the project is capable of report the execution logs directly to Azure DevOps using Application Insights.

## 2. Project structure [WIP]<a id="project-structure"></a>

## 3. Project Set up <a id="installation-guide"></a>

### Step by step guide <a id="step-by-step-guide"></a>

1. Install node v18 or higher. Official download site: [Node js](https://nodejs.org/en/download).
2. Install git , also include git bash as your default shell. Official download site: [Git](https://git-scm.com).
3. Create a ssh key in your machine and configure it in Azure DevOps. Read more [here](https://learn.microsoft.com/en-us/azure/devops/repos/git/use-ssh-keys-to-authenticate?view=azure-devops)
4. Clone the project `git clone git@ssh.dev.azure.com:v3/LERETAPROJECT/QAOps/QA_Automation_Template` and go to the root of the project.
5. Be sure that your default shell in your terminal is bash (powershell will not work)
6. Create your `.env` file using the `.env.template` file as example. As this is a template project, we are providing the .env file content, but don't do this in your own project, each user should configure it with their credentials, keys, tokens, and additional private information.

   ```
   APP_ENVIRONMENT=PROD
   BASE_URL=https://www.demoblaze.com/
   APP_LOGIN_USER=demo-user-bullet
   APP_LOGIN_PASSWORD=VktqcGV6cEhhQjl2QGpI
   ```

7. Run the following commands:

   > :warning: If you are implementing this template in a monorepo, it is necessary to update the 'prepare' script in the package.json. Husky works with the .git folder, so you need to navigate to the project's root before running it. I.e., if the automation project is two levels under the root, you need to update the command and it should looks like this:

   ```
   "prepare": "npx playwright install && cd .. && cd .. && husky install automationProjectPath/.husky"
   ```

   1. ````
                  npm install
            ```

            Make sure that this command logs husky and playwright drivers being installed successfully.
            `    husky - Git hooks installed
      Downloading Chromium ____ (playwright build ____) from https://playwright.azureedge.net/builds/chromium/____
      122 Mb [====================] 100% 0.0s
      Chromium ____ (playwright build ____) downloaded to C:\Users\____AppData\Local\ms-playwright\chromium-____
      Downloading FFMPEG playwright build ____ from https://playwright.azureedge.net/builds/ffmpeg/____
      1.4 Mb [====================] 100% 0.0s
      FFMPEG playwright build ____ downloaded to C:\Users\____\AppData\Local\ms-playwright\ffmpeg-1009
      Downloading Firefox ____ (playwright build ____) from https://playwright.azureedge.net/builds/firefox/1429/firefox-____
      80.5 Mb [====================] 100% 0.0s
      Firefox 119.0 (playwright build ____) downloaded to C:\Users\____y\AppData\Local\ms-playwright\firefox-____
      Downloading Webkit ____ (playwright build ____) from https://playwright.azureedge.net/builds/webkit/____
      46.4 Mb [====================] 100% 0.0s
      Webkit____ (playwright build ____) downloaded to C:\Users\____
       `
            2.(OPTIONAL) If not you will have to run

            ```
            npm run prepare
            ```

      ````

   2. Verify that the `.husky\pre-commit` file exists, if not run:
      ```
      npx husky add .husky/pre-commit "npm run precommit"
      ```

8. On the first execution or after changes, remember to transpile the code using the `npm pretest` command.

### Trouble shooting <a id="trouble-shooting"></a>

- <b>Syscall spawn bash error:</b>

  This is caused by the configuration of your terminal, verify what is missing to run npm commands properly or switch to bash

  ```
  npm ERR! code ENOENT
  npm ERR! syscall spawn bash
  npm ERR! errno -4058
  npm ERR! enoent spawn bash ENOENT
  npm ERR! enoent This is related to npm not being able to find a file.
  npm ERR! enoent
  ```

- <b>The code is not scanned or formatted automatically after executing a 'git commit' command:</b>

  Open the .husky/pre-commit file and verify that its content is

  ```
  #!/usr/bin/env sh
  . "$(dirname -- "$0")/_/husky.sh"

  npm run precommit
  ```

  If the file doesn't exist, run the commands 3.3 & 3.4 of the [Set up guide](#installation-guide). If the file exist but the content is different, you can manually update it.

### Suggested plugins in VS Code <a id="plugins"></a>

- [Playwright Test for VSCode](https://marketplace.visualstudio.com/items?itemName=ms-playwright.playwright)
- WIP

## 4. Creating new tests <a id="new-test"></a>

The project is built to reuse its different components between the performance and functional test, using a POM approach for the UI tests and a base controller and templates for the APIs.

### Creating a UI test [WIP]<a id="new-ui-test"></a>

Steps to create a test:

1. Create the Playwright spec file in the `tests/ui` path following the [_spec-file-name_].spec.ts convention. This file will contain the main test flow. Examples:

   - `tests/ui/add-to-cart.spec.ts`
   - `tests/ui/cart/add-to-cart.spec.ts`

2. Create a folder in the `shared/ui/pages` path with the name of your page. Inside this folder, create these 2 files:
   - Elements: Contains the web element selectors
   - Actions: Imports the selectors and contains business-centered actions that are used in the spec file.

### Creating an API test [WIP]<a id="new-api-test"></a>

Steps to create a test:

1. Create the Playwright spec file in the `tests/api` path following the [_spec-file-name_].spec.ts convention. This file will contain the main test flow. Examples:

   - `tests/api/add-to-cart.spec.ts`
   - `tests/api/cart/add-to-cart.spec.ts`

2. Create a file in the `shared\api\templates\requests` path following the [_spec-file-name_].request.ts convention. This file will contain the specific information of the API, as parameters, payload or import headers. Examples:

   - `shared/api/templates/requests/cart.request.ts`
   - `shared/api/templates/requests/cart/cart.request.ts`

3. If specific headers are required, create a file in the `shared\api\templates\headers` path following the [_spec-file-name_].headers.ts convention. Examples:
   - `shared/api/templates/headers/add-to-cart.headers.ts`
   - `shared/api/templates/headers/cart/add-to-cart.headers.ts`

### Creating a performance test <a id="new-performance-test"></a>

In this project, the Artillery tests are composed of 2 files, the Scenario and the Processor:

- Scenario: A YAML file with the configuration of the test. Among other things, it includes the test data, environment variables, how many virtual users it will run with, and the test that will be executed with this config.
- Processor: The script that contains the code of the test.

Steps to create a test:

1. Create a folder in `test\performance\scenarios` with the name of the main feature that you want to test. The name should follow the kebab case style (lower case and separated by hyphen), i.e.: 'add-to-cart'. Inside this new folder, create a new one called `ui`, `api`, or both depending on the approach that is going to be used.
2. Create the scenario in its corresponding folder following this convention:

   - [_test-case_]-[_number-of-virtual-users_].e2e.yaml

   Example:

   - `tests\performance\scenarios\add-to-cart\api\add-to-cart-1vu.e2e.yaml`
   - `tests\performance\scenarios\add-to-cart\ui\add-to-cart-1vu.e2e.yaml`

   You can use the example as a template for your own test, but for more information visit the [Artillery website](https://www.artillery.io/docs/reference/engines/playwright). Note: For reference, the project is using the Playwright Engine.

3. Create the test processor in the `src\performance-tests\processors` folder, feel free to create sub-folders in this path if necessary. The processor name convention is:

   - [_test-case_].[_testing-level_].spec.ts

   Examples:

   - `add-product-to-cart.ui.spec.ts`
   - `add-product-to-cart.api.spec.ts`

## 5. Project <a id="running-tests"></a>

The commands in the project can be classified as testing commands, base commands, and utility commands.

- Testing commands:

  - `npm run performance:add-to-cart:api`: Run the 'add to cart' API performance test.
  - `npm run performance:add-to-cart:ui`: Rus the 'add to cart' UI performance test.
  - `npm run performance:add-to-cart:all`: Run all 'add to cart' performance test.
  - `npm run playwright:api`: Run the 'add to cart' API functional test.
  - `npm run playwright:ui`: Run the 'add to cart' UI functional test.
  - `npm run playwright:all`: Run all 'add to cart' functional test.

- Base commands: They are used internally to prepare the test execution, they are:
  - `npm run artillery`: Identifies the artillery tests
  - `npm run performance`: Base command for performance tests.
  - `npm run playwright`: Base command for functional tests.
- Utility commands:
  - `npm run pretest`: compiles the code from the shared, support and tests directories from TS to JS code.
  - `npm run lint`: executes an ESLint analysis.
  - `npm run lint:fix`: executes the fixes that ESLint can do automatically.
  - `npm run prettier`: executes a Prettier analysis.
  - `npm run prettier:fix`: Run the Prettier formatter in the project.
  - `npm run precommit`: executes the Prettier formatter and ESLint analysis. Husky executes this command automatically before each commit.
  - `npm run prepare`: installs required elements from Husky and Playwright that are not installed with the `npm install` command.
  - `npm run report-2-appinsights`: Send the test logs to application insights.

## 6. Additional features <a id="additional-features"></a>

The project has also implemented a static code analyzer, a code formatter, and git hooks to ensure best practices and a common style that can be maintained independent of how many people or teams are working on it.

### Linter - ESLint <a id="linter"></a>

A linter is a static code analysis tool that helps in maintaining code quality and consistency by automatically identifying and flagging potential errors, stylistic issues and, in general, bad practices. ESLint is the linter used in this project, and it is configured to verify these topics:

- Coding practices in the TS, JS and YAML files.
- Files and folders naming.
- Project structure.
- Playwright implementations.

To run the linter, execute this command in the root: <br>
`npm run lint`

ESLint can fix some of the code issues automatically with this command: <br>
`npm run lint:fix`

For more information about the ESLint rules in this project, read the `README-ESLINT-RULES.md` file.

### Code formatter - Prettier <a id="code-formatter"></a>

Prettier automatically format code according to a consistent and predefined style, enhancing code readability and maintainability. It saves developers time by automating the tedious task of manually aligning code and handling formatting details.

To run a prettier analysis, execute this command in the root: <br>
`npm run prettier`

The code can be formatted ith this command: <br>
`npm run prettier:fix`

### Git hooks - Husky <a id="git-hooks"></a>

Husky is a tool that facilitates the integration of Git hooks in the project. In our case, this integration automates the code analysis with ESLint and Prettier before completing a commit, and failing it in case that the code doesn't complies with the expected standards.

This practice ensures that the codebase adheres to predefined quality standards and remains consistent, and as Husky centralize the configuration of the hook, their management, setup, and maintenance are simpler compared with other alternatives.

> :warning: To avoid unexpected changes, the Git hook is configured to run the analysis but not the fixes, if your commit fails please verify what should be fixed.
