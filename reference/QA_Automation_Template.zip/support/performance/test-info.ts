import { ScenarioContext } from "artillery";
import { AppEnvironments } from "../../shared/assets/application-urls";
import { EventStatus, TestScope } from "../../shared/types/performance/types";
import { Nullable } from "../../shared/types/global.type";

export default class TestInfo {
  private _context: ScenarioContext;

  private _vus?: number;

  private _uuid: string;

  private _appEnvironment: AppEnvironments;

  private _testEnvironment?: string;

  private _scenarioName: string;

  private _scenario: string;

  private _aut?: string;

  private _testScope: TestScope = TestScope.UNSPECIFIED;

  status: EventStatus;

  error?: any;

  testData: { [name: string]: unknown };

  constructor(context: ScenarioContext) {
    this._context = context;
    this.status = EventStatus.UNCOMPLETED;
    this._vus = Number(this._context.vars["vus"]);
    this._uuid = this._context.vars.$uuid;
    const scenarioFromYaml = this._context["scenario"].name.split(".");
    this._scenario = scenarioFromYaml.length > 1 ? scenarioFromYaml[1] : scenarioFromYaml[0];
    this._aut = scenarioFromYaml.length > 1 ? scenarioFromYaml[0] : undefined;
    if (process.env.APP_ENVIRONMENT == null)
      throw new Error(
        "An environment for the application should be set up in environment variables as APP_ENVIRONMENT"
      );
    this._appEnvironment = process.env.APP_ENVIRONMENT as AppEnvironments;
    if (this._appEnvironment == null)
      throw new Error(
        `Invalid environment value: '${this._appEnvironment}'. Set your environment variable APP_ENVIRONMENT to a valid value ('DEV' | 'QA' | 'DEMO' | 'PROD')`
      );
    this._testEnvironment = this._context.vars.$environment;
    const CTX_SCENARIO_NAME: string = `user.scenario.${this._context["scenario"].name}`;
    if (this.vus) {
      if (CTX_SCENARIO_NAME.endsWith("vu") === false) {
        this._scenarioName = `${CTX_SCENARIO_NAME}.${this.vus}vu`;
      } else {
        this._scenarioName = CTX_SCENARIO_NAME;
      }
    } else {
      this._scenarioName = CTX_SCENARIO_NAME;
    }
    this.testData = {};
  }

  public getVarFromYaml(varName: string): any {
    this.testData[varName] = this._context.vars[varName] ?? null;
    return this._context.vars[varName];
  }

  public getVar(varName: string, isSecret = false): any {
    if (!isSecret) this.testData[varName] = this._context.vars[varName] ?? null;
    return this._context.vars[varName];
  }

  public get currentStatus(): string {
    return EventStatus[this.status];
  }

  public get uid(): string {
    return this._uuid;
  }

  public get vus(): Nullable<number> {
    return this._vus;
  }

  public get yamlEnvironment(): Nullable<string> {
    return this._testEnvironment;
  }

  public get appEnvironment(): AppEnvironments {
    return this._appEnvironment;
  }

  public get scenarioFullName(): string {
    return this._scenarioName;
  }

  public get scenarioName(): string {
    return this._scenario;
  }

  public set testScope(scope: TestScope) {
    this._testScope = scope;
    this._scenarioName = this._scenarioName.replace(
      "user.scenario.",
      `user.scenario.${TestScope[this._testScope]}.`
    );
  }

  public set aut(appUnderTest: string) {
    this._aut = appUnderTest;
    if (this.testScope == null)
      this._scenarioName = this._scenarioName.replace(
        "user.scenario.",
        `user.scenario.${this._aut}.`
      );
    else
      this._scenarioName = this._scenarioName.replace(
        `user.scenario.${TestScope[this._testScope]}.`,
        `user.scenario.${TestScope[this._testScope]}.${this._aut}.`
      );
  }

  public logTestData(keyName: string, value: any) {
    this.testData[keyName] = value;
  }

  public toJson(): { [key: string]: any } {
    return {
      status: EventStatus[this.status],
      vus: this._vus,
      uuid: this._uuid,
      appEnvironment: this._appEnvironment,
      testEnvironment: this._testEnvironment,
      aut: this._aut,
      scenario: this._scenario,
      scenarioName: this._scenarioName,
      testScope: TestScope[this._testScope],
      testData: this.testData,
      error: this.error,
    };
  }
}
