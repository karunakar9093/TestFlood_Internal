import { Nullable } from "shared/types/global.type";
import TestInfo from "./test-info";

export default class Metric {
  public eventName: string;

  public metricName: string;

  public testInfo: TestInfo;

  public readonly testEvents: Record<string, Nullable<number>> = {};

  constructor(testInfo: TestInfo, metricName?: string) {
    this.metricName = metricName ?? `vusers.event.length`;
    this.testInfo = testInfo;
  }

  public add(durationInSeconds: number, eventName: string = this.testInfo.scenarioFullName): void {
    this.testEvents[eventName] = durationInSeconds;
  }

  /**
   * Function to add an event duration to the test report summary. Overrides the event if an event with the same name is already there.
   * @param {Promise<T>} fn Operation to measure , result will be in seconds
   * @param eventName The name for the histogram that is going to be created for this event
   * @returns {T} The result for the measured operation
   */
  public async addEventDuration<T>(
    fn: Promise<T>,
    eventName: string = this.testInfo.scenarioFullName
  ): Promise<T> {
    const startTime = Date.now();
    this.testEvents[eventName] = undefined;
    const result = await fn;
    const endTime = Date.now();
    this.testEvents[eventName] = (endTime - startTime) / 1000;
    return result;
  }
}
