import { EventEmitter, ScenarioContext } from "artillery";
import Metrics from "./metric";
import TestInfo from "./test-info";
import { ensureFile, readFileSync, writeFileSync } from "fs-extra";
import { EventStatus } from "../../shared/types/performance/types";

const writeTestDataToFile = async (testInfo: TestInfo) => {
  const TEST_INFO_FILE = "./reports/test.json";
  await ensureFile(TEST_INFO_FILE);
  const oldContent = JSON.parse(readFileSync(TEST_INFO_FILE, "utf-8") || "[]");
  oldContent.push(testInfo.toJson());
  writeFileSync(TEST_INFO_FILE, JSON.stringify(oldContent));
};
export async function test(
  ee: EventEmitter,
  context: ScenarioContext,
  testFunction: (testInfo: TestInfo, metrics: Metrics) => Promise<void> | void
): Promise<void> {
  const testInfo = new TestInfo(context);
  const metrics = new Metrics(testInfo);
  try {
    await testFunction(testInfo, metrics);
    for (const key in metrics.testEvents) {
      ee.emit("histogram", key, metrics.testEvents[key]);
    }
    testInfo.status = EventStatus.COMPLETED;
    await writeTestDataToFile(testInfo);
  } catch (error) {
    for (const key in metrics.testEvents) {
      ee.emit("histogram", key, metrics.testEvents[key]);
    }
    testInfo.status = EventStatus.FAILED;
    testInfo.error = (error.message ? error.message : String(error)).substring(0, 180);
    await writeTestDataToFile(testInfo);
    throw error;
    // ee.emit('counter', 'vusers.failed', 1);
    // ee.emit('counter', 'vusers.completed', -1);
  }
}
