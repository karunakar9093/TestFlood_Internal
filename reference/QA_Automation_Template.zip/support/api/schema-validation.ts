import Ajv, { Options } from "ajv";
import addFormats from "ajv-formats";

export default class SchemaValidation {
  ajv: Ajv;

  /**
   *
   */
  constructor(private opts?: Options) {
    this.ajv = new Ajv(this.opts);
    addFormats(this.ajv);
  }

  validate(data: any, schema: any): boolean {
    const validate = this.ajv.compile(schema);
    return validate(data);
  }

  parse<T>(data: any, schema: any): T {
    const validate = this.ajv.compile<T>(schema);
    if (validate(data)) {
      return data as T;
    } else {
      const error =
        validate.errors
          ?.map((err) => `Invalid data: ${err.message} (path: ${err.instancePath})`)
          .join("\n,") ?? "Invalid data: Unknown error:";
      throw new Error(error);
    }
  }
}
