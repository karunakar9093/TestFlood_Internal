import { Locator as NativeLocator } from "playwright-core/lib/client/locator";
import { Locator } from "playwright-core/types/types";

declare module "playwright-core/types/types" {
  export class Locator {
    newMethod(): void;
  }
}
// eslint-disable-next-line
Locator.prototype.newMethod = function (): any {
  return this == null ? "" : this;
};
Object.defineProperty(NativeLocator.prototype, "newMethod", {
  value: function newMethod() {
    return "Hi " + this + "!";
  },
  writable: true,
  configurable: true,
});
