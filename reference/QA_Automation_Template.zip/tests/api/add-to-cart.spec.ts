import { randomProduct } from "../../shared/assets/test-data/products";
import { authenticatedTest, expect } from "../../shared/fixtures/auth.fixture";
import CartApi from "../../shared/api/controllers/cart.api";

authenticatedTest("Add product to the cart using product id", async ({ authToken, page }) => {
  const articleId: string = randomProduct().productId;
  const cartApi = new CartApi(page.request, authToken);
  const addToCartRequest = await cartApi.addToCart(articleId);
  expect(addToCartRequest.status()).toBe(200);
});

authenticatedTest(
  "Add existing product to the cart without request id",
  async ({ authToken, page }) => {
    const articleId = randomProduct().productId;
    const cartApi = new CartApi(page.request, authToken);
    cartApi.willFailOnStatusCode = false;
    const addToCartRequest = await cartApi.addToCart(articleId, "");
    expect(addToCartRequest.status()).toBe(500);
    expect(await addToCartRequest.text()).toContain("The server encountered an internal error");
  }
);
