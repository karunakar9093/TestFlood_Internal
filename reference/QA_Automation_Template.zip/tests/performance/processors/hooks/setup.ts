import { Context } from "vm";
import { EventEmitter, Next } from "artillery";
import Logger from "../../../../support/logger";
/**
 * Hook to get session storage from bullet login using playwright sandbox, if the environment is prod it grabs an static template
 * from this project and injects a token passed manually vía env variable BEARER_TOKEN
 * @param {ScenarioContext} _ctx The virtual user's context.
 *    - context.vars is a dictionary containing all defined variables
 *    - context.scenario is the scenario definition for the scenario currently being run by the virtual user
 * @param {EventEmitter} _ee  An event emitter that can be used to communicate with Artillery
 * @param {Next} next The callback which must be called for the scenario to continue. Pass an Error object to stop the current VU.
 */
export const setUp = async (ctx: Context, _ee: EventEmitter, next: Next) => {
  Logger.info("Testrun Started");
  Logger.info(`Logged in bullet app '${process.env.APP_ENVIRONMENT}' environment`);
  ctx.vars["authToken"] = require("../../../../shared/assets/sessions/session.json").token;
  next();
};

export const tearDown = async (_ctx: Context, _ee: EventEmitter, next: Next) => {
  Logger.info("Testrun Finished");
  next();
};
