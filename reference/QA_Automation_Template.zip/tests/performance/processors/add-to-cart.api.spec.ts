import { Page } from "@playwright/test";
import { expect } from "chai";
import { test } from "../../../support/performance/test-processor";
import { EventEmitter, ScenarioContext } from "artillery";
import { TestScope } from "../../../shared/types/performance/types";
import CartApi from "../../../shared/api/controllers/cart.api";
// HOOK METHODS - these need to be imported to be exposed to the artillery scenario file
export { setUp } from "./hooks/setup";
export { tearDown } from "./hooks/setup";

/**
 * Scenario method used for artillery
 * @param {Page} page Instance of playwright page coming by indepency injection
 * @param {ScenarioContext} context The virtual user's context.
 *    - context.vars is a dictionary containing all defined variables
 *    - context.scenario is the scenario definition for the scenario currently being run by the virtual user
 * @param {EventEmitter} ee  An event emitter that can be used to communicate with Artillery
 */
export async function addToCart(page: Page, context: ScenarioContext, ee: EventEmitter) {
  await test(ee, context, async (testInfo, metric) => {
    testInfo.testScope = TestScope.API;
    const articleId = testInfo.getVarFromYaml("articleId");
    expect(articleId).not.to.be.null;
    const authToken = testInfo.getVar("authToken", true);
    const cartApi = new CartApi(page.request, authToken);
    const addToCartRequest = cartApi.addToCart(articleId);
    const addToCartResponse = await metric.addEventDuration(addToCartRequest);
    expect(addToCartResponse.status()).to.equal(200);
  });
}
