import { Page } from "@playwright/test";
import { expect } from "chai";
import { HomePage } from "../../../shared/ui/pages/home.actions.po";
import { ArticlePage } from "../../../shared/ui/pages/article.actions.po";
import { NavHeaderPage } from "../../../shared/ui/pages/navHeader.actions.po";
import { CartPage } from "../../../shared/ui/pages/cart.actions.po";
import { test } from "../../../support/performance/test-processor";
import { EventEmitter, ScenarioContext } from "artillery";
import { TestScope } from "../../../shared/types/performance/types";
import { urlPaths } from "../../../shared/assets/application-urls";
// HOOK METHODS - these need to be imported to be exposed to the artillery scenario file
export { setUp } from "./hooks/setup";
export { tearDown } from "./hooks/setup";
/**
 * Scenario method used for artillery
 * @param {Page} page Instance of playwright page coming by indepency injection
 * @param {ScenarioContext} context The virtual user's context.
 *    - context.vars is a dictionary containing all defined variables
 *    - context.scenario is the scenario definition for the scenario currently being run by the virtual user
 * @param {EventEmitter} ee  An event emitter that can be used to communicate with Artillery
 */
export async function addToCart(page: Page, context: ScenarioContext, ee: EventEmitter) {
  await test(ee, context, async (testInfo, metric) => {
    testInfo.testScope = TestScope.UI;
    const articleName = testInfo.getVarFromYaml("articleName");
    expect(articleName).not.to.be.null;
    const homePage = new HomePage(page);
    await homePage.goto();
    page = await homePage.openArticleByName(articleName);

    await metric.addEventDuration(addToCartAction(page, articleName));

    const navHeaderPage = new NavHeaderPage(page);
    page = await navHeaderPage.goToCart();

    const cartPage = new CartPage(page);
    await cartPage.verifyArticleIsPresent(articleName);
  });
}

/**
 * Performs the 'Add to Cart' action that will be measured in the performance test
 *
 * @param {Page} page - The page object to create the POMs.
 * @param {string} articleName - The name of the article to be added to the cart.
 * @returns {Promise<void>} A promise that resolves when the 'Add to Cart' action is complete.
 */
async function addToCartAction(page: Page, articleName: string) {
  const responsePromise = page.waitForResponse(urlPaths.cart.api.addToCart().toString());
  const articlePage = new ArticlePage(page);
  await articlePage.verifyArticleName(articleName);
  await articlePage.addArticleToCart();
  await responsePromise; //wait until the 'add to cart' request receives a response
}
