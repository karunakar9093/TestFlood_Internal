import { test } from "@playwright/test";
import { HomePage } from "../../shared/ui/pages/home.actions.po";
import { ArticlePage } from "../../shared/ui/pages/article.actions.po";
import { NavHeaderPage } from "../../shared/ui/pages/navHeader.actions.po";
import { CartPage } from "../../shared/ui/pages/cart.actions.po";
import { randomProduct } from "../../shared/assets/test-data/products";
import { urlPaths as UrlPaths } from "../../shared/assets/application-urls";

test("Add product to the cart", async ({ page }) => {
  const articleName = randomProduct().productName;

  const homePage = new HomePage(page);
  await homePage.goto();
  page = await homePage.openArticleByName(articleName);

  const responsePromise = page.waitForResponse(UrlPaths.cart.api.addToCart().toString());
  const articlePage = new ArticlePage(page);
  await articlePage.verifyArticleName(articleName);
  await articlePage.addArticleToCart();
  await responsePromise; //wait until the 'add to cart' action finish in the BE to reduce flakiness

  const navHeaderPage = new NavHeaderPage(page);
  page = await navHeaderPage.goToCart();

  const cartPage = new CartPage(page);
  await cartPage.verifyArticleIsPresent(articleName);
});
